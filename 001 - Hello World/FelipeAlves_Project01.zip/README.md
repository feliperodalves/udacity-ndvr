VR Nanodegree Course 1 Project
-------------------------------------------------------------------------------

Felipe Rodrigues Alves
01:30:00 to complete all modifications and testing.
Google VR SDK for Unity v.1.0


-------------------------------------------------------------------------------
Please don't delete this file.


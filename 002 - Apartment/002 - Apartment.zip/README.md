VR Nanodegree Course 2 Project
-------------------------------------------------------------------------------

Felipe Rodrigues Alves
06:00:00 to complete all modifications and testing.
Google VR SDK for Unity v.1.7.0

Observations:
- I was unable to set Pointer Reaction on Globe and to integrate Teleport script to work within the Globe Animation script
- Just tested with Lightmap resolution 2, 5, 20, 40 and the final project with 80 texels per unit
- Changed Lightmap Size to 4096 and Lightmap Padding to 100 texels

-------------------------------------------------------------------------------
Please don't delete this file.

